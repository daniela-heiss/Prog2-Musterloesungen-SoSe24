#pragma once
#include "cDiesellok.h"
#include "cPersonenwagen.h"

class cDieselTriebWagen :
    public cDiesellok, public cPersonenwagen
{
private:

public:
    double bereitstellen(double treibstoff);

    cDieselTriebWagen(double trieb_in = 1800, double gew_in = 40000, int fahrg = 12);

};