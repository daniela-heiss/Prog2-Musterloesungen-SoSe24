#pragma once
#include "cLokomotive.h"
class cDiesellok :
    public cLokomotive
{
private:
    double tanken();
public:
    cDiesellok(double tr_in = 4800.0, double ge_in = 87000.0);
    double bereitstellen(double treibstoff);

};

