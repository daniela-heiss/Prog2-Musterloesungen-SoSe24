#include "cWaggon.h"

cWaggon::cWaggon(double ge_in):cSchienenfahrzeug(ge_in)
{
}

void cWaggon::ankuppeln()
{
	cout << "Ich lass mich ziehen" << endl;
}
