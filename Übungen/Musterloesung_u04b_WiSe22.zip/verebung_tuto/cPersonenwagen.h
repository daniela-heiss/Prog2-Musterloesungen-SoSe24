#pragma once
#include "cWaggon.h"
class cPersonenwagen :
    public cWaggon
{
private:
    int fahrgastzahl;
public:
    cPersonenwagen(int fahr_in = 12, double gew_in = 27300.0);
    int einsteigen(int rein);
    int aussteigen(int raus);
};

