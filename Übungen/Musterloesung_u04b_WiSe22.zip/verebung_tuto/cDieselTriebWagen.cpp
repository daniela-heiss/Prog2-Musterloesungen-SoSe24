#include "cDieselTriebWagen.h"		//u04b
#include <iostream>
using namespace std;



cDieselTriebWagen::cDieselTriebWagen(double trieb_in, double gew_in, int fahrg) :cDiesellok(trieb_in, gew_in), cPersonenwagen(fahrg, gew_in) {

}

double cDieselTriebWagen::bereitstellen(double treibstoff) {

	treibstoff = treibstoff - (treibstoff * 0.02);
	cout << "Fargastraum aufheizen" << endl;
	return cDiesellok::bereitstellen(treibstoff);

}