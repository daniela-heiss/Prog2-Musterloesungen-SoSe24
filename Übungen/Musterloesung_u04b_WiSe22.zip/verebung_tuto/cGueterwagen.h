#pragma once
#include "cWaggon.h"
class cGueterwagen :
    public cWaggon
{
private: 
    double nutzlast;
public:
    cGueterwagen(double nutz_in = 80000.0, double ge_in = 18500.0);
    double zuladen(double lastplus);
    double abladen(double lastweg);
    double get_gewicht();
};

