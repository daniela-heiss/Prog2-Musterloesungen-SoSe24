/*
* Datum: 
* autor: Herve Mbatchou
* ver.....
* mtNr: 
*/
#include "cSchienenfahrzeug.h"
#include "cGueterwagen.h"
#include "cPersonenwagen.h"
#include "cDiesellok.h"
#include "cDampflok.h"
#include "cDieselTriebWagen.h"


int main() {
	cGueterwagen packdrauf;
	cPersonenwagen pullman1;
	cDiesellok v200;
	cDampflok s3_6;

	// Mit den Objekten arbeiten:
	cout << "Startgewicht des Gueterwagens: " << packdrauf.get_gewicht() << endl;
	cout << "Startgewicht des Personenwagens: " << pullman1.get_gewicht() << endl;
	cout << "Startgewicht der Diesellok: " << v200.get_gewicht() << endl;
	cout << "Startgewicht der Dampflok: " << s3_6.get_gewicht() << endl;
	cout << "s3_6 hat Power " << s3_6.bereitstellen(7430.0) << endl;
	cout << "v200 hat Power " << v200.bereitstellen(6080.0) << endl;
	pullman1.ankuppeln();
	packdrauf.ankuppeln();
	v200.ankuppeln();
	cout << "Ladung nach Abladen 20000.0: " << packdrauf.abladen(20000) << endl;
	cout << "Gewicht Gueterwagen packdrauf dann: " << packdrauf.get_gewicht() << endl;
	cout << "Gaeste im Personanwagen nach Zusteigen 100: " << pullman1.einsteigen(100)
		<< endl;
	cout << "Ende" << endl;

	// u04b - Daniela Heiss, 15.12.22
	cout << endl;
	cout << "u04b" << endl;

	cDieselTriebWagen schienenbus1;
	cDieselTriebWagen kauzbergbahn(36220.0, 687.5, 57);

	cout << "Gewicht Schienenbus1: " << schienenbus1.cSchienenfahrzeug::get_gewicht() << endl;
	cout << "Gewicht kauzbergbahn: " << kauzbergbahn.cSchienenfahrzeug::get_gewicht() << endl;
	cout << "Gaeste im Schienenbus nach Zusteigen 42: " <<
		schienenbus1.einsteigen(42) << endl;

	return 0;
}