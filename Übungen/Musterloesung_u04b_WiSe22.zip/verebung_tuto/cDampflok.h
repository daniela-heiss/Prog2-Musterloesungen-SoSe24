#pragma once
#include "cLokomotive.h"
class cDampflok :
    public cLokomotive
{
private:
    double anheizen();
public:
    double bereitstellen(double kohlen);
    cDampflok(double tr_in = 2250.0, double ge_in = 120000.0);

};

