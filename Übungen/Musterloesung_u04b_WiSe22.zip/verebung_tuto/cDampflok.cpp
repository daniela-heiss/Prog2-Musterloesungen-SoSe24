#include "cDampflok.h"

double cDampflok::anheizen()
{
    return 300.0;
}

double cDampflok::bereitstellen(double kohlen)
{
    double treibstoffmenge = (kohlen - anheizen()) * 0.75;
    return cLokomotive::bereitstellen(treibstoffmenge);
}

cDampflok::cDampflok(double tr_in, double ge_in): cLokomotive(tr_in, ge_in)
{
}
