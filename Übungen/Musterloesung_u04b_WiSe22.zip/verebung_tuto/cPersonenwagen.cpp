#include "cPersonenwagen.h"

cPersonenwagen::cPersonenwagen(int fahr_in, double gew_in):cWaggon(gew_in)
{
	fahrgastzahl = fahr_in;
}

int cPersonenwagen::einsteigen(int rein)
{
	if (fahrgastzahl + rein <= 117) {
		fahrgastzahl = fahrgastzahl + rein;
	}
	else {
		cout << "Anzahl wurde schon erreicht.";
	}
	 
	return fahrgastzahl;
}

int cPersonenwagen::aussteigen(int raus)
{
	if (fahrgastzahl - raus >= 0) {
		fahrgastzahl = fahrgastzahl - raus;
	}
	else {
		cout << "der Zug ist leer";
	}
	return fahrgastzahl;
}
