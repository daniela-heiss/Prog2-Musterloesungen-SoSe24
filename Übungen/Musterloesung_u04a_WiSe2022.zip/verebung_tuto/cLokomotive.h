#pragma once
#include "cSchienenfahrzeug.h"
class cLokomotive :
    public cSchienenfahrzeug
{
private:
    double triebkraft;
public:
    cLokomotive(double = 0.0, double = 0.0);
    void ankuppeln();
    double bereitstellen(double treibstoff);
};

