#include "cGueterwagen.h"

cGueterwagen::cGueterwagen(double nutz_in, double ge_in): cWaggon(ge_in)
{
	nutzlast = nutz_in;
}

double cGueterwagen::zuladen(double lastplus)
{
	nutzlast = lastplus + nutzlast;
	return nutzlast;
}

double cGueterwagen::abladen(double lastweg)
{
	nutzlast = nutzlast - lastweg;
	return nutzlast;
}

double cGueterwagen::get_gewicht()
{
	double result = cSchienenfahrzeug::get_gewicht() + nutzlast;
	return result;
}
