#pragma once
#include "cSchienenfahrzeug.h"
class cWaggon :
    public cSchienenfahrzeug
{
public:
    cWaggon(double ge_in = 0.0);
    void ankuppeln();
};

