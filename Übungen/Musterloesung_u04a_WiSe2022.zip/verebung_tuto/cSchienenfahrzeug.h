#pragma once
#include <iostream>
using namespace std;

class cSchienenfahrzeug
{
private:
	double gewicht;
public:
	cSchienenfahrzeug(double = 0.0);
	double get_gewicht();
};

