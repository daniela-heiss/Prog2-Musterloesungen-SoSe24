#include "cLokomotive.h"

cLokomotive::cLokomotive(double tr_in , double ge_in): cSchienenfahrzeug(ge_in)
{
	triebkraft = tr_in;
}

void cLokomotive::ankuppeln()
{
	cout << "ich zieh Euch alle" << endl;
}

double cLokomotive::bereitstellen(double treibstoff)
{
	double resultat = ((get_gewicht() + treibstoff) * triebkraft) / 1000;
	return resultat;
}
