#include "cDiesellok.h"

double cDiesellok::tanken()
{
    double tankmenge = 2000.0;
    return tankmenge;
}

cDiesellok::cDiesellok(double tr_in, double ge_in): cLokomotive(tr_in, ge_in)
{
}

double cDiesellok::bereitstellen(double treibstoff)
{
    double treibstoffMenge = treibstoff + tanken();
    double result = cLokomotive::bereitstellen(treibstoffMenge);
    return result;
}
