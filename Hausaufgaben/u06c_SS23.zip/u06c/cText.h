#pragma once
#include "cLine.h"

class cText
{
private:
	string title;
	cLine* text;
	int count;
public:
	cText(string title_in, string file_in);
	~cText();
	void changeTitle(string newTitle);
	void writeLine(int num, string newText);
	void textPrint();

};

