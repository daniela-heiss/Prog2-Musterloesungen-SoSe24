#include "cText.h"

cText::cText(string title_in, string file) {
	title = title_in;
	count = 0;
	
	ifstream in_file(file);
	string line;

	getline(in_file, line);
	cLine* line_act = new cLine(line);
	count++;

	while (getline(in_file, line)) {
		line_act = line_act->newLine(line);
		count++;
	}

	in_file.close();

	text = line_act;
}

cText::~cText() {
	if (text) {
		delete text;
	}
	cout << "Destruktion Text" << endl;
}

void cText::changeTitle(string newTitle) {
	title = newTitle;
}

void cText::writeLine(int num, string newText) {
	cLine* help = text;
	int counter = count - num;

	while (counter != 0 && help->getPrev() != NIL) {
		help = help->getPrev();
		counter--;
	}

	help->setLine(newText);
}

void cText::textPrint() {
	cout << title << endl;
	text->printLine();
}
