#pragma once
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

#define NIL (cLine*) 0

class cLine
{
private:
	string line;
	cLine* prevLine;
public:
	cLine(string line_in, cLine* prevLine_in = NIL);
	~cLine();
	cLine* newLine(string line_in);
	void setLine(string line_in);
	void printLine();

	cLine* getPrev();
	string getLine();

};

