#include "cLine.h"
#include "cText.h"

int main() {

	cText spielText("Rohtext", "data.txt");
	spielText.textPrint();
	cout << endl;

	spielText.changeTitle("Gedicht");
	spielText.textPrint();
	cout << endl;

	spielText.writeLine(5, "als fuenftes ists mir einerlei");
	spielText.textPrint();
	cout << endl;

	return 0;
}