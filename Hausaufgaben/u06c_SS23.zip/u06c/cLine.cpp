#include "cLine.h"

cLine::cLine(string line_in, cLine* prevLine_in) 
{
	line = line_in;
	prevLine = prevLine_in;
}
cLine::~cLine()
{
	if (prevLine != NIL) {
		delete prevLine;
	}
	cout << "Destruktion Zeile" << endl;
}
cLine* cLine::newLine(string line_in) {
	return new cLine (line_in, this);
}

void cLine::setLine(string line_in) {
	line = line_in;
}

void cLine::printLine() {
	if (prevLine != NIL) {
		prevLine->printLine();
	}

	cout << line << endl;
}

cLine* cLine::getPrev() {
	return prevLine;
}

string cLine::getLine() {
	return line;
}
